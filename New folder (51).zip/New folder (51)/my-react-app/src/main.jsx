// main.jsx (or index.jsx)
import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App'; // Make sure to import App
import { BrowserRouter as Router } from 'react-router-dom';

// Create a root element for React 18+
const root = ReactDOM.createRoot(document.getElementById('root'));

// Render the app using the root
root.render(
  <Router>
    <App />
  </Router>
);
