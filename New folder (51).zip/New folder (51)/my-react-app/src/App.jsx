import React, { useState } from 'react';
import { Route, Routes } from 'react-router-dom';
import HomePage from './components/HomePage';
import SignUp from './components/SignUp';
import PageHome from './components/pagehome';
import Video from './components/video';
import Profile from './components/Profile';
import VideoUpload from './components/videoUpload';  // Capitalize the component name
import Login from './components/Login';

function App() {
  const [sideBar, setSideBar] = useState(true); // Manage Sidebar visibility with boolean

  // Function to set Sidebar visibility
  const setSideBarFunc = (value) => {
    setSideBar(value);
  };

  return (
    <div>
      <Routes>
        <Route path="/" element={<HomePage sideBar={sideBar} setSideBarFunc={setSideBarFunc} />} />
        <Route path="/d" element={<PageHome />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/watch/:id" element={<Video />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/:id/upload" element={<VideoUpload />} />{/* Corrected component name */}
        <Route path="/signup" element={<SignUp />} />{/* Corrected component name */}
        <Route path="/login" element={<Login/>} />{/* Corrected component name */}
      </Routes>
    </div>
  );
}

export default App;
