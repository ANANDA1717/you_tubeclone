import React from 'react';
import './Sidebar.css';  // Ensure this file has your styles
import HomeIcon from '@mui/icons-material/Home';
import VideocamIcon from '@mui/icons-material/Videocam';
import SubscriptionsIcon from '@mui/icons-material/Subscriptions';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import RecentActorsIcon from '@mui/icons-material/RecentActors';
import HistoryIcon from '@mui/icons-material/History';
import PlayListPlayIcon from '@mui/icons-material/PlaylistPlay';
import SmartDisplayOutlinedIcon from '@mui/icons-material/SmartDisplayOutlined';
import WatchLaterOutlinedIcon from '@mui/icons-material/WatchLaterOutlined';
import ThumbUpAltOutlinedIcon from '@mui/icons-material/ThumbUpAltOutlined';
import ContentCutIcon from '@mui/icons-material/ContentCut';

const SidebarLink = ({ icon, label, onClick, ariaLabel }) => (
  <span onClick={onClick} aria-label={ariaLabel} className="sidebar-link">
    {icon} {label}
  </span>
);

const SidebarImageLink = ({ src, alt, label, onClick }) => (
  <span onClick={onClick} aria-label={label}>
    <img className="imgicon" src={src} alt={alt} />
    {label}
  </span>
);

const Sidebar = ({ sideBar, setSideBarFunc }) => {
  const closeSidebarOnOutsideClick = (e) => {
    setSideBarFunc(false); // Close the sidebar
  };

  const preventSidebarCloseOnLinkClick = (e) => {
    e.stopPropagation(); // Prevent the sidebar from closing
  };

  return (
    <div
      className={`home-sideBar ${sideBar ? 'open' : 'home-sideBar-hidden'}`}
      onClick={closeSidebarOnOutsideClick} // Close the sidebar when clicking outside
    >
      {/* Sidebar content */}
      <nav className="home_sideBarTop">
        <div className="home_sideBarTopOption">
          <SidebarLink icon={<HomeIcon />} label="Home" onClick={preventSidebarCloseOnLinkClick} ariaLabel="Home" />
          <SidebarLink icon={<VideocamIcon />} label="Shorts" onClick={preventSidebarCloseOnLinkClick} ariaLabel="Shorts" />
          <SidebarLink icon={<SubscriptionsIcon />} label="Subscription" onClick={preventSidebarCloseOnLinkClick} ariaLabel="Subscription" />
        </div>
      </nav>

      <div className="home_sideBarMiddle">
        <section className="home_sideBarTopOption">
          <SidebarLink icon={<ChevronRightIcon />} label="You" onClick={preventSidebarCloseOnLinkClick} ariaLabel="You" />
          <SidebarLink icon={<RecentActorsIcon />} label="Your Channels" onClick={preventSidebarCloseOnLinkClick} ariaLabel="Your Channels" />
          <SidebarLink icon={<HistoryIcon />} label="History" onClick={preventSidebarCloseOnLinkClick} ariaLabel="History" />
          <SidebarLink icon={<PlayListPlayIcon />} label="Playlist" onClick={preventSidebarCloseOnLinkClick} ariaLabel="Playlist" />
          <SidebarLink icon={<SmartDisplayOutlinedIcon />} label="Your Videos" onClick={preventSidebarCloseOnLinkClick} ariaLabel="Your Videos" />
          <SidebarLink icon={<WatchLaterOutlinedIcon />} label="Watch Later" onClick={preventSidebarCloseOnLinkClick} ariaLabel="Watch Later" />
          <SidebarLink icon={<ThumbUpAltOutlinedIcon />} label="Liked Videos" onClick={preventSidebarCloseOnLinkClick} ariaLabel="Liked Videos" />
          <SidebarLink icon={<ContentCutIcon />} label="Your Clips" onClick={preventSidebarCloseOnLinkClick} ariaLabel="Your Clips" />
        </section>
      </div>

      <div className="home_sideBarMiddle">
        <section className="home_sideBarTopOption">
          <div className="home_sideBarTopOptionHeader">
            <SidebarLink icon={<ChevronRightIcon />} label="Subscription" onClick={preventSidebarCloseOnLinkClick} ariaLabel="Subscription" />
            <div className="home_sideBarTopOption">
              <SidebarImageLink
                src="https://www.medianews4u.com/wp-content/uploads/2019/08/Aaj-Tak.jpg"
                alt="Aaj Tak"
                label="Aaj Tak"
                onClick={preventSidebarCloseOnLinkClick}
              />
              <SidebarImageLink
                src="https://th.bing.com/th/id/OIP.Y925GukOqox8wB46vagsAwHaEK?w=314&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7"
                alt="NDTV"
                label="NDTV"
                onClick={preventSidebarCloseOnLinkClick}
              />
              <SidebarImageLink
                src="https://www.medianews4u.com/wp-content/uploads/2019/08/Aaj-Tak.jpg"
                alt="Aaj Tak"
                label="Aaj Tak"
                onClick={preventSidebarCloseOnLinkClick}
              />
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default Sidebar;
