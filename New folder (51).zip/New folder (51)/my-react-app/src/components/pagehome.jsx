import React from "react";
import HomePage from "./HomePage"; // Import HomePage component
import YouTubeThumbnail from "./YouTubeThumbnail";

const PageHome = () => {
  return (
    <div className="homea">
      <HomePage /> {/* Render HomePage component */}
    </div>
  );
};

export default PageHome;
