import React, { useState, Suspense, lazy, useCallback } from 'react';
import { Link } from 'react-router-dom';
import MenuIcon from '@mui/icons-material/Menu';
import SearchIcon from '@mui/icons-material/Search';
import MicIcon from '@mui/icons-material/Mic';
import PersonIcon from '@mui/icons-material/Person';
import VideoCallIcon from '@mui/icons-material/VideoCall';
import './Navbar.css'; 

// Lazy load the Login component to optimize performance
const Login = lazy(() => import('./Login'));

const Navbar = ({ setSideBarFunc }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [userPic, setUserPic] = useState('https://img.icons8.com/?size=100&id=O9K5DaypaVKw&format=png&color=000000');
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [loginVisible, setLoginVisible] = useState(false); // Track if login modal should be visible

  const handleSearchChange = useCallback((event) => {
    setSearchQuery(event.target.value);
  }, []);

  const handleSearchSubmit = (event) => {
    event.preventDefault();
    console.log('Search Query:', searchQuery); 
  };

  const handleMicClick = () => {
    if ('webkitSpeechRecognition' in window) {
      const recognition = new window.webkitSpeechRecognition();
      recognition.lang = 'en-US';
      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        setSearchQuery(transcript);
      };
      recognition.start();
    } else {
      alert('Speech recognition is not supported in this browser.');
    }
  };

  const handleDropdownToggle = () => {
    setDropdownOpen(!dropdownOpen);
  };

  const openSidebar = () => {
    setSideBarFunc(true);
  };

  // Open the login modal when clicked
  const openLoginModal = () => {
    setLoginVisible(true);
  };

  // Close the login modal
  const closeLoginModal = () => {
    setLoginVisible(false);
  };

  return (
    <div className="navbar">
      <div className="navbar-left">
        <div className="menu-icon" onClick={openSidebar}>
          <MenuIcon fontSize="small" />
        </div>

        <Link to="/" className="logo">
          <img
            src="https://www.freeiconspng.com/uploads/hd-youtube-logo-png-transparent-background-20.png"
            alt="YouTube Logo"
            className="logo-img"
          />
        </Link>
      </div>

      <div className="navbar-search">
        <form onSubmit={handleSearchSubmit} className="search-form">
          <input
            type="text"
            value={searchQuery}
            onChange={handleSearchChange}
            placeholder="Search..."
            className="search-input"
          />
          <button type="submit" className="search-button">
            <SearchIcon fontSize="small" />
          </button>
          <button type="button" className="mic-button" onClick={handleMicClick}>
            <MicIcon fontSize="small" />
          </button>
        </form>
      </div>

      <Link to="/123/upload" style={{ textDecoration: 'none' }}>
        <div className="upload">
          <VideoCallIcon sx={{ fontSize: 25, cursor: 'pointer', color: 'white' }} />
        </div>
      </Link>

      <div className="user-profile">
        {userPic ? (
          <img
            src={userPic}
            alt="User Profile"
            className="user-pic"
            onClick={handleDropdownToggle}
          />
        ) : (
          <PersonIcon
            className="user-pic-icon"
            onClick={handleDropdownToggle}
          />
        )}

        {dropdownOpen && (
          <div className="dropdown-menu">
            <Link to="/profile" className="dropdown-item">Profile</Link><br />
            <span className="dropdown-item" onClick={openLoginModal}>Login</span><br />
            <Link to="/logout" className="dropdown-item">Logout</Link>
          </div>
        )}
      </div>

      {/* Overlay and Login modal */}
      {loginVisible && (
        <>
          <div className="overlay" onClick={closeLoginModal}></div>
          <div className="login-modal">
            <Suspense fallback={<div>Loading...</div>}>
              <Login />
            </Suspense>
            <button className="close-modal" onClick={closeLoginModal}>Close</button>
          </div>
        </>
      )}
    </div>
  );
};

export default React.memo(Navbar);
