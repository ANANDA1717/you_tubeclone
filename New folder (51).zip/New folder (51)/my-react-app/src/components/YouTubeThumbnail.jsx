// src/components/YouTubeThumbnail.js
import React, { useState } from "react";
import CircularProgress from "@mui/material/CircularProgress";
import "./YouTubeThumbnail.css"; // Ensure this file includes necessary styles

const YouTubeThumbnail = ({ videoId, thumbnailUrl, videoTitle = "Watch this video", username = "User", likes = 1000 }) => {
  const [loading, setLoading] = useState(true);  // Track loading state
  const [error, setError] = useState(false);  // Track image load errors

  const videoUrl = `https://www.youtube.com/watch?v=${videoId}`;

  // Fallback thumbnail in case no thumbnail is provided or error occurs
  const defaultThumbnail = "https://via.placeholder.com/1200x675?text=No+Thumbnail";

  return (
    <div className="youtube_Video">
      <div className="youtube_thumbnailBox">
        <a href={videoUrl} target="_blank" rel="noopener noreferrer" className="thumbnail_link">
          {loading && (
            <div className="loader_container">
              <CircularProgress size={50} color="primary" /> {/* MUI Circular Loader */}
            </div>
          )}

          <img
            src={error ? defaultThumbnail : thumbnailUrl}
            alt={videoTitle}
            className={`youtube_thumbnail ${loading ? "hidden" : ""}`} // Hide image while loading
            onLoad={() => setLoading(false)} // Hide loader when image loads
            onError={() => { setError(true); setLoading(false); }} // Handle errors
          />
        </a>
      </div>

      {/* Video Details */}
      <div className="youtube_videoDetails">
        <p className="youtube_videoTitle">{videoTitle}</p>
        <div className="youtube_videoMeta">
          <span className="youtube_username">{username}</span>
          <span className="youtube_likes">{likes} Likes</span>
        </div>
        <a href={videoUrl} className="watchVideoLink" target="_blank" rel="noopener noreferrer">
          Watch the video
        </a>
      </div>
    </div>
  );
};

export default YouTubeThumbnail;
