import React, { useState } from 'react';
import axios from 'axios';
import Navbar from './Navbar';
import YouTubeIcon from '@mui/icons-material/YouTube';
import './videoUpload.css';

const VideoUpload = () => {
    const [isUploading, setIsUploading] = useState(false);
    const [uploadedImageUrl, setUploadedImageUrl] = useState(null);
    const [uploadedVideoUrl, setUploadedVideoUrl] = useState(null);
    const [popupMessage, setPopupMessage] = useState('');
    const [showPopup, setShowPopup] = useState(false);

    // Function to upload media (image or video)
    const uploadMedia = async (e, mediaType) => {
        const file = e.target.files[0];
        if (!file) return showPopupMessage(`No ${mediaType} selected!`, 'error');

        setIsUploading(true);
        const data = new FormData();
        data.append('file', file);
        data.append('upload_preset', 'sairam');
        data.append('folder', 'sairam'); // Ensure files are stored in 'sairam' folder
        data.append('resource_type', mediaType); // 'image' or 'video'

        try {
            const uploadUrl = `https://api.cloudinary.com/v1_1/ddauv1hum/${mediaType}/upload`;
            const { data: response } = await axios.post(uploadUrl, data, {
                headers: { 'Content-Type': 'multipart/form-data' },
            });

            if (response.secure_url) {
                if (mediaType === 'image') {
                    setUploadedImageUrl(response.secure_url);
                } else if (mediaType === 'video') {
                    setUploadedVideoUrl(response.secure_url);
                }
                showPopupMessage(`${mediaType} uploaded successfully!`, 'success');
            } else {
                showPopupMessage(`Upload failed. Check Cloudinary settings.`, 'error');
            }
        } catch (error) {
            console.error(`Error uploading ${mediaType}:`, error);
            showPopupMessage(`Error uploading ${mediaType}.`, 'error');
        } finally {
            setIsUploading(false);
            e.target.value = ''; // Clear file input
        }
    };

    // Function to show popups
    const showPopupMessage = (message, type) => {
        setPopupMessage({ text: message, type });
        setShowPopup(true);
        setTimeout(() => setShowPopup(false), 3000);
    };

    return (
        <div>
            <Navbar />
            <div className="videoupload">
                <div className="videouploaddesc">
                    <div className="uploadone">
                        <YouTubeIcon sx={{ fontSize: '74px', color: 'red' }} />
                        <div className='uploadTitle'>Upload Video</div>
                    </div>
                    <div className='uploadForm'>
                        <input type="text" placeholder='Title of Video' className='uploadForminput' />
                        <input type="text" placeholder='Description' className='uploadForminput' />
                        <input type="text" placeholder='Category' className='uploadForminput' />
                        
                        <div>
                            Thumbnail:
                            <input type="file" accept="image/*" onChange={(e) => uploadMedia(e, 'image')} disabled={isUploading} />
                        </div>
                        {uploadedImageUrl && (
                            <div>
                                <p>Uploaded Thumbnail:</p>
                                <img src={uploadedImageUrl} alt="Uploaded Thumbnail" width="200px" />
                            </div>
                        )}

                        <div>
                            Video:
                            <input type="file" accept="video/mp4,video/webm,video/*" onChange={(e) => uploadMedia(e, 'video')} disabled={isUploading} />
                        </div>
                        {uploadedVideoUrl && (
                            <div>
                                <p>Uploaded Video:</p>
                                <video src={uploadedVideoUrl} controls width="300px" />
                            </div>
                        )}
                    </div>
                    
                    <div className='uploadBtns'>
                        <button className='uploadBtn_form' disabled={isUploading}>Upload</button>
                        <button className='uploadBtn_form'>Home</button>
                    </div>
                </div>
            </div>

            {/* Popup Notification */}
            {showPopup && (
                <div className={`popup ${popupMessage.type}`}>
                    {popupMessage.text}
                </div>
            )}
        </div>
    );
};

export default VideoUpload;
