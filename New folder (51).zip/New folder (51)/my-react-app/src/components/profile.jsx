import React from 'react';
import Navbar from './Navbar';
import Sidebar from './Sidebar';
import './profile.css'; // Importing the CSS file
import ArrowRightIcon from '@mui/icons-material/ArrowRight'; 

const ProfilePage = () => {
    return (
        <div>
            <Navbar />
            <div className='side'>
                <Sidebar />
            </div>
            {/* Profile Header Section */}
            <div className="profile-header">
                <div className="profile-top-section">
                    <div className='profilr'>
                        <div className="profile-top-section-profile">
                            <img 
                                src="https://www.pngkey.com/png/detail/550-5509803_js-logo-javascript-logo-circle-png.png" 
                                alt="Profile" 
                                className="profile-top-section-img" 
                            />
                        </div>
                        <div className="profile-top-section-info">
                            <h1>John Doe</h1>
                            <p>Web Developer</p>
                        </div>
                    </div>
                </div>
                <div className='profile_videos'>
                    <span>Videos</span> &nbsp; 
                    <ArrowRightIcon style={{ fontSize: '3rem', marginTop: '7px', verticalAlign: 'middle' }} />
                </div>
                <div className="linebar"></div>
                <div className="profilevideo_block">
                    <div className="profilevideosblockview">
                        <img 
                            className="profilevideosblockview_thumbnail" 
                            src="https://www.pngkey.com/png/detail/550-5509803_js-logo-javascript-logo-circle-png.png" 
                            alt="JavaScript Logo"
                        />
                        <div className='video_about_title'>aneyonghaseo</div>
                        <div className='video_about_title_desc'>ottoge jineaeseyo</div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ProfilePage;
