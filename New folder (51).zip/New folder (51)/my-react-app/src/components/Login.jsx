import React, { useState, useCallback } from 'react';
import './Login.css'; // Custom styles for login modal
import YouTubeIcon from '@mui/icons-material/YouTube';

const LoginPage = () => {
  const [login, setLogin] = useState(false); // Modal visibility state
  const [loginFeild, setLoginFeild] = useState({
    userName: '',
    password: ''
  });

  const openModal = useCallback(() => setLogin(true), []);
  const closeModal = useCallback(() => setLogin(false), []);

  const handleOnChangeInput = useCallback((event, name) => {
    setLoginFeild(prevState => ({
      ...prevState,
      [name]: event.target.value
    }));
  }, []);

  const handleLoginSubmit = useCallback(() => {
    console.log("Login credentials: ", loginFeild);
    // Handle login logic here (authentication or validation)
  }, [loginFeild]);

  return (
    <div>
      <button onClick={openModal}>Open Login Modal</button>

      {/* Only render the modal when it's visible */}
      {login && (
        <div className="modal-overlay">
          <div className="modal-content">
            {/* Login Modal Content */}
         <div className='n1' >    <YouTubeIcon sx={{ fontSize: '74px', color: 'red' }} /><h2> Login Page</h2></div>
            <form onSubmit={(e) => { e.preventDefault(); handleLoginSubmit(); }}>
              <div>
                
                <input
                  id="userName"
                  type="text"
                  value={loginFeild.userName}
                  onChange={(e) => handleOnChangeInput(e, 'userName')}
                  placeholder="Enter username"
                  required
                />
              </div>
              <div>
               
                <input
                  id="password"
                  type="password"
                  value={loginFeild.password}
                  onChange={(e) => handleOnChangeInput(e, 'password')}
                  placeholder="Enter password"
                  required
                />
              </div>
              <button type="submit">Login</button>
            </form>

            {/* Close (X) Button */}
            <button onClick={closeModal} className="close-x-btn">X</button>
          </div>
        </div>
      )}
    </div>
  );
};

// Optional: Wrap with React.memo if needed to optimize rendering
export default React.memo(LoginPage);
