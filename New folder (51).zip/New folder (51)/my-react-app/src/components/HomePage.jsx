import React, { useState, useEffect, useCallback } from 'react';
import Navbar from './Navbar';
import Sidebar from './Sidebar';
import './HomePage.css'; // Your custom styles
import { Link } from 'react-router-dom';

// Lazy load the YouTubeThumbnail component
const YouTubeThumbnail = React.lazy(() => import('./YouTubeThumbnail')); 

const HomePage = () => {
  const [sideBar, setSideBar] = useState(true); // Sidebar visibility state
  const [isInView, setIsInView] = useState(Array(10).fill(false)); // Track which thumbnails are in view

  // Function to toggle the sidebar visibility
  const setSideBarFunc = (value) => {
    setSideBar(value); // Show or hide the sidebar
  };

  const options = [
    "Live", "Movies", "Sports", "News", "Technology", "Events", "Podcasts", 
    "Comedy", "Travel", "Food", "Fashion", "Art", "Gaming",
    "Music", "Books", "Health", "Science", "Education", "Fitness", "Business",
    "Lifestyle", "Politics", "Environment", "History", "Photography", "Cars",
    "Animals", "Parenting", "DIY", "Real Estate", "Culture", "Celebrity", 
    "Finance", "Shopping", "Mental Health", "Architecture", "Spirituality"
  ];

  const optionsRef = useCallback((node, index) => {
    if (node) {
      const observer = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) {
            setIsInView((prevState) => {
              const newState = [...prevState];
              newState[index] = true;
              return newState;
            });
            observer.disconnect();
          }
        },
        { threshold: 0.5 } // Trigger when 50% of the element is visible
      );
      observer.observe(node);
    }
  }, []);

  return (
    <div className="homepage">
      <Navbar setSideBarFunc={setSideBarFunc} />
      <div className={`homePage_options ${sideBar ? 'withSidebar' : ''}`}>
        {options.map((option, index) => (
          <div 
            key={index} 
            ref={node => optionsRef(node, index)} 
            className="homePage_option"
          >
            {option}
          </div>
        ))}
      </div>

      <div className='you_tube'>
        {[...Array(10)].map((_, index) => (
          <React.Suspense key={index} fallback={<div>Loading...</div>}>
            {isInView[index] && (
              <Link to='/watch/N1GfjzSJmiQ'>
                <YouTubeThumbnail 
                  videoId="dQw4w9WgXcQ" 
                  thumbnailUrl={`https://img.youtube.com/vi/dQw4w9WgXcQ/0.jpg`} 
                />
              </Link>
            )}
          </React.Suspense>
        ))}
      </div>

      <Sidebar sideBar={sideBar} setSideBarFunc={setSideBarFunc} />
    </div>
  );
};

export default HomePage;
