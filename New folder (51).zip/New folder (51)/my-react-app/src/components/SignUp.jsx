import React, { useState } from 'react';
import Navbar from './Navbar';
import './videoUpload.css';
import YouTubeIcon from '@mui/icons-material/YouTube';
import CircularProgress from '@mui/material/CircularProgress';
import axios from 'axios';

const SignUp = () => {
  const [signUpField, setSignUpField] = useState({
    channelname: '',
    username: '',
    password: '',
    about: '',
    profilepic: '',
  });

  const [uploadedImageUrl, setUploadedImageUrl] = useState(
    'https://th.bing.com/th/id/OIP.M0jJePz0aCxAvaxqntLjLgHaK1?rs=1&pid=ImgDetMain'
  );
  const [isUploading, setIsUploading] = useState(false);

  const handleInputField = (e) => {
    setSignUpField({
      ...signUpField,
      [e.target.name]: e.target.value,
    });
  };

  const uploadImage = async (e) => {
    setIsUploading(true);
    const file = e.target.files[0];
    if (!file) {
      alert('No file selected!');
      setIsUploading(false);
      return;
    }

    const data = new FormData();
    data.append('file', file);
    data.append('upload_preset', 'sairam');
    data.append('folder', 'sairam');

    try {
      const response = await axios.post(
        'https://api.cloudinary.com/v1_1/ddauv1hum/image/upload',
        data,
        { headers: { 'Content-Type': 'multipart/form-data' } }
      );

      if (response.data.secure_url) {
        setUploadedImageUrl(response.data.secure_url);
        setSignUpField((prev) => ({ ...prev, profilepic: response.data.secure_url }));
        alert('Image uploaded successfully!');
      } else {
        alert('Upload failed. Check Cloudinary settings.');
      }
    } catch (error) {
      alert('Error uploading image. Check Cloudinary settings.');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div>
      <Navbar />
      <div className="videoupload">
        <div className="videouploaddesc">
          <div className="uploadone">
            <YouTubeIcon sx={{ fontSize: '74px', color: 'red' }} />
            <div className="uploadTitle">Sign Up</div>
          </div>
          <div className="uploadForm1">
            <input type="text" name="channelname" placeholder="Channel Name" value={signUpField.channelname} onChange={handleInputField} className="uploadForminput" />
            <input type="text" name="username" placeholder="User Name" value={signUpField.username} onChange={handleInputField} className="uploadForminput" />
            <input type="password" name="password" placeholder="Password" value={signUpField.password} onChange={handleInputField} className="uploadForminput" />
            <input type="text" name="about" placeholder="About your Channel" value={signUpField.about} onChange={handleInputField} className="uploadForminput" />
            <div>
              <input type="file" onChange={uploadImage} disabled={isUploading} />
            </div>
            {isUploading && <CircularProgress style={{ marginTop: '10px' }} />} 
            <div className="img_src">
              <img src={uploadedImageUrl} width="100px" height="100px" alt="Profile" loading="lazy" style={{ borderRadius: '50%',marginLeft:'55%' }} />
            </div>
            <div className="uploadBtns">
              <div className="uploadBtn_form">Sign Up</div>
              <div className="uploadBtn_form">Home Page</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignUp;
