import React from 'react'
import './video.css';
import Navbar from './Navbar';
import ThumbUpOutlined from '@mui/icons-material/ThumbUpOutlined';
import ThumbDownOutlined from '@mui/icons-material/ThumbDownOutlined';

const Video = () => {
  return (
    <div className='scrolly'>
            <Navbar />
    <div className='video'>
      <div className='videoPostSection'>
        <div className='video_youtube'>
          <video width = "400" controls autoPlay className='video_youtube_video'>
            <source src = {"https://youtu.be/N1GfjzSJmiQ?si=x87WxSv2XQPXzr6C"} type = "video/mp4"/>
            <source src = {"https://youtu.be/N1GfjzSJmiQ?si=x87WxSv2XQPXzr6C"} type = "video/webm"/>
            Your Browser does not support the video
          </video>
        </div>
      <div className='video_youtubeAbout'>
       <div className='youtube_title'>{"Javascipt for Begineer"}</div>
      <div className='youtube_video_Profile_Block'>
       <div className='youtube_video_Profile_Block_left'>
       <div className='youtube_video_Profile_Block_left_img'>
        <img className = "youtube_video_Profile_Block_left_image" src = "https://www.pngkey.com/png/detail/550-5509803_js-logo-javascript-logo-circle-png.png"/>
       </div>
       <div className="youtubeVideo_subsView">
                  <div className="youtubePostProfileName">{"User1"}</div>
                  <div className="youtubePostProfileSubs">{"2024-07-09"}</div>
       </div>
         <div className='subscribeBtnyoutube'>
           SUBSCRIBE
         </div>
        <div className='youtube_video_likeBlock'>
         <div className='youtube_video_likeBlock_like'>
          <ThumbUpOutlined sx={{ color: 'white' }} />
          <div className='likeBlocknumber'>32</div>
          </div>
          <div className='lineyoutube'></div>
         <div className='youtube_video_likeBlock_dislike'>
          <ThumbDownOutlined sx={{ color: 'white' }} />
          <div className='likeBlocknumber'>32</div>
        </div>
       </div>
       </div>
       <div className='scrollmenu'>
       <div className='youtube_video_aboutdesc'>
          <div>2024-09-07</div>
          <div >This is cool video</div>
        </div>
       </div>
       <div className='youtubeCommentSection'>
     <div className='youtubeCommentSectionTitle'> 2 Comments</div>
      <div className='youtubeselfcomments'>
        <img className='youtube_profile_comments' src = "https://www.pngkey.com/png/detail/550-5509803_js-logo-javascript-logo-circle-png.png"/>
        <div className='addAComment'>
          <input type = "text" className='addACommentinput' placeholder = "Add a Comment"/>

          <div className='cancelComment'>Cancel</div>
          <div className='cancelComment'>Comment</div>
        </div>
      </div>
      </div>
       </div>
       </div>
        
      </div>
      <div className='videoSuggestions'>
        <div className='videoSuggestionsBlock'>
          <div className='video_suggestion_thumbnail'>
            <img  className = "video_suggestion_thumbnail_img"src = "https://www.pngkey.com/png/detail/550-5509803_js-logo-javascript-logo-circle-png.png"/>
          </div>
         < div className = "video_suggestions_about">
          <div className='video_suggestions_about_title'>anneyong haseyo ottoge jineaeseyo</div>
         </div>
        </div>
        <div className='videoSuggestionsBlock'>
          <div className='video_suggestion_thumbnail'>
            <img  className = "video_suggestion_thumbnail_img"src = "https://www.pngkey.com/png/detail/550-5509803_js-logo-javascript-logo-circle-png.png"/>
          </div>
         < div className = "video_suggestions_about">
          <div className='video_suggestions_about_title'>anneyong haseyo ottoge jineaeseyo</div>
         </div>
        </div>
        <div className='videoSuggestionsBlock'>
          <div className='video_suggestion_thumbnail'>
            <img  className = "video_suggestion_thumbnail_img"src = "https://www.pngkey.com/png/detail/550-5509803_js-logo-javascript-logo-circle-png.png"/>
          </div>
         < div className = "video_suggestions_about">
          <div className='video_suggestions_about_title'>anneyong haseyo ottoge jineaeseyo</div>
         </div>
        </div>
        <div className='videoSuggestionsBlock'>
          <div className='video_suggestion_thumbnail'>
            <img  className = "video_suggestion_thumbnail_img"src = "https://www.pngkey.com/png/detail/550-5509803_js-logo-javascript-logo-circle-png.png"/>
          </div>
         < div className = "video_suggestions_about">
          <div className='video_suggestions_about_title'>anneyong haseyo ottoge jineaeseyo</div>
         </div>
        </div>
        <div className='videoSuggestionsBlock'>
          <div className='video_suggestion_thumbnail'>
            <img  className = "video_suggestion_thumbnail_img"src = "https://www.pngkey.com/png/detail/550-5509803_js-logo-javascript-logo-circle-png.png"/>
          </div>
         < div className = "video_suggestions_about">
          <div className='video_suggestions_about_title'>anneyong haseyo ottoge jineaeseyo</div>
         </div>
        </div>
        <div className='videoSuggestionsBlock'>
          <div className='video_suggestion_thumbnail'>
            <img  className = "video_suggestion_thumbnail_img"src = "https://www.pngkey.com/png/detail/550-5509803_js-logo-javascript-logo-circle-png.png"/>
          </div>
         < div className = "video_suggestions_about">
          <div className='video_suggestions_about_title'>anneyong haseyo ottoge jineaeseyo</div>
         </div>
        </div>
      </div>
    </div>
    </div>
    
  )
}

export default Video;