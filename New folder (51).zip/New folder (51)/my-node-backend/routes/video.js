const express = require("express");
const router = express.Router();
const videoController = require("../controllers/video");
const auth = require("../middleware/authentication");

// Route to upload a video (Ensure it is POST)
router.post("/video", auth, videoController.uploadVideo);

module.exports = router;
