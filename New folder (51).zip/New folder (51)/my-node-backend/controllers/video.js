const Video = require('../models/video');

exports.uploadVideo = async (req, res) => {
  try {
    console.log("Authenticated User:", req.user);

    // Ensure req.user exists
    if (!req.user || !req.user._id) {
      return res.status(401).json({ error: "Unauthorized access" });
    }

    const { title, description, videoLink, videoType, thumbnail } = req.body;

    // Validate required fields
    if (!title || !videoLink) {
      return res.status(400).json({ error: "Title and video link are required." });
    }

    const videoUpload = new Video({
      user: req.user._id,
      title,
      description,
      videoLink,
      videoType,
      thumbnail,
    });

    try {
      await videoUpload.save();
      res.status(201).json({ success: true, video: videoUpload });
    } catch (err) {
      return res.status(500).json({ error: "Database error", message: err.message });
    }

  } catch (error) {
    console.error("Server Error:", error);
    res.status(500).json({ error: "Server error", message: error.message });
  }
};
