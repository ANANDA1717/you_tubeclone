const User = require("../models/user");
const jwt = require('jsonwebtoken');

const cookieOptions = {
  secure: false,
  sameSite: 'Lax',
};

exports.signUp = async (req, res) => {
  try {
    const { channelname, userName, about, profilePic, password } = req.body;

    if (!channelname || !userName || !password) {
      return res.status(400).json({ message: "Missing required fields" });
    }

    const existingUser = await User.findOne({ $or: [{ userName }, { channelname }] });

    if (existingUser) {
      return res.status(409).json({ message: "User already exists" });
    }

    const newUser = new User({ channelname, userName, about, profilePic, password });

    await newUser.save();

    console.log("User signed up successfully:", newUser);
    res.status(201).json({ message: "User signed up successfully!" });
  } catch (error) {
    console.error("Error during sign-up:", error);
    res.status(500).json({ message: "Server error" });
  }
};

exports.signIn = async (req, res) => {
  try {
    const { userName, password } = req.body;

    const user = await User.findOne({ userName });

    if (user && user.password === password) {
      const token = jwt.sign({ userId: user._id }, 'secretkey10', { expiresIn: "1h" }); // ✅ Removed `cookieOptions`

      res.cookie('token', token, cookieOptions); // ✅ Use `cookieOptions` here
      res.json({ message: "Logged in successfully", success: true, token: token });
      
    } else {
      res.status(401).json({ error: "Invalid credentials" });
    }
  } catch (error) {
    console.error("Error during sign-in:", error);
    res.status(500).json({ error: "Server error" });
  }
};

exports.logout = async (req, res) => {
  res.clearCookie('token', cookieOptions).json({ message: "Logged out successfully" });
};
