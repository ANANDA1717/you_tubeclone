const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema(
  {
    channelname: { type: String, required: true, unique: true }, // lowercase "n"
    userName: { type: String, required: true, unique: true },
    about: { type: String },
    profilePic: { type: String },
    password: { type: String, required: true },
  },
  { timestamps: true } 
);

module.exports = mongoose.model("User", UserSchema);
